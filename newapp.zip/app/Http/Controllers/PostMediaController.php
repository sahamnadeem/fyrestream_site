<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostMediaController extends Controller
{
    //
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostTypeController extends Controller
{
    //
}

<?php $__env->startSection('main-content'); ?>
    <div class="container" id="main-cont" style="margin-bottom: 20px !important;">
        <div class="row top-bar justify-content-center p-2" style="color: rgb(170,170,170);">
            <div class="col-auto col-sm-12 col-md-auto col-lg-auto col-xl-auto m-auto text-center p-2" style="font-size: 0.8em;"><span style="color: rgb(130,130,130);"><strong>Featured </strong>:&nbsp;</span><span><img src="assets/img/output-onlinepngtools.png" width="30px"></span><span><strong>Modeling Expo 2019</strong></span></div>
            <div class="col-sm-12 col-md-auto col-lg-auto col-xl-auto m-auto text-center"
                 style="font-size: 0.8em;"><span><img src="assets/img/output-onlinepngtools.png" width="30px"></span><span><strong>Photography By Sean Studios</strong></span></div>
            <div class="col-sm-12 col-md-auto col-lg-auto col-xl-auto m-auto text-center" style="font-size: 0.8em;"><span><img src="assets/img/output-onlinepngtools.png" width="30px"></span><span><strong>Vogue Magazien Award</strong></span></div>
            <div class="col-auto col-sm-12 col-md-auto col-lg-auto col-xl-auto m-auto text-center" style="font-size: 0.8em;"><span><img src="assets/img/output-onlinepngtools.png" width="30px"></span><span><strong>Kyeli's Keto Diet&nbsp;</strong></span></div>
            <div class="col-md-auto col-lg-auto col-xl-auto m-auto text-center" style="font-size: 0.8em;"><span><img src="assets/img/output-onlinepngtools.png" width="30px"></span><span><strong>Modeling Expo&nbsp;</strong></span></div>
        </div>
        <div class="row mt-2">
            <div class="col m-0">
                <div class="shaddow card-fyre d-flex" style="border-radius:10px;over-flow:hidden;">
                    <div class="side-user">
                        <div class="row m-0">
                            <div class="col p-2"><span class="m-2" style="border: 1px solid grey;padding: 5px 5px 5px 5px;background-image: linear-gradient(#ff2727,#c50202);border-radius: 5px;font-size: 0.5em;"><i class="fas fa-share-alt" style="font-size: 1.4em;color: rgb(255,255,255);"></i></span></div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;background-image: linear-gradient(#ff2727,#c50202);font-size: 0.5em;border:1px solid #c50202">
                            <div class="col m-0 p-0"><span class="m-2" style="font-size: 1.5em;"><i class="fas fa-star m-1" style="font-size: 1.4em;color: rgb(255,172,48);"></i><span class="m-1" style="color: rgb(255,255,255);"><strong>TOP</strong></span></span>
                            </div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;font-size:10px;">
                            <div class="col m-auto p-0">
                                <div class="row m-0">
                                    <div class="col m-auto">
                                        <div style="width:50px; height:50px;position:relative;"><img src="assets/img/IMG_20151014_212349.jpg" width="50px;" style="border-radius:50%;" height="50px"><i class="fas fa-circle" style="position: absolute;bottom: 0;right: 0;font-size: 1em;color: rgb(35,177,0);"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;font-size:10px;">
                            <div class="col m-auto p-0">
                                <div class="row m-0">
                                    <div class="col m-auto">
                                        <div style="width:50px; height:50px;position:relative;"><img src="assets/img/IMG_20151014_212349.jpg" width="50px;" style="border-radius:50%;" height="50px"><i class="fas fa-circle" style="position: absolute;bottom: 0;right: 0;font-size: 1em;color: rgb(35,177,0);"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;font-size:10px;">
                            <div class="col m-auto p-0">
                                <div class="row m-0">
                                    <div class="col m-auto">
                                        <div style="width:50px; height:50px;position:relative;"><img src="assets/img/IMG_20151014_212349.jpg" width="50px;" style="border-radius:50%;" height="50px"><i class="fas fa-circle" style="position: absolute;bottom: 0;right: 0;font-size: 1em;color: rgb(35,177,0);"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;font-size:10px;">
                            <div class="col m-auto p-0">
                                <div class="row m-0">
                                    <div class="col m-auto">
                                        <div style="width:50px; height:50px;position:relative;"><img src="assets/img/IMG_20151014_212349.jpg" width="50px;" style="border-radius:50%;" height="50px"><i class="fas fa-circle" style="position: absolute;bottom: 0;right: 0;font-size: 1em;color: rgb(35,177,0);"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;font-size:10px;">
                            <div class="col m-auto p-0">
                                <div class="row m-0">
                                    <div class="col m-auto">
                                        <div style="width:50px; height:50px;position:relative;"><img src="assets/img/IMG_20151014_212349.jpg" width="50px;" style="border-radius:50%;" height="50px"><i class="fas fa-circle" style="position: absolute;bottom: 0;right: 0;font-size: 1em;color: rgb(35,177,0);"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;font-size:10px;">
                            <div class="col m-auto p-0">
                                <div class="row m-0">
                                    <div class="col m-auto">
                                        <div style="width:50px; height:50px;position:relative;"><img src="assets/img/IMG_20151014_212349.jpg" width="50px;" style="border-radius:50%;" height="50px"><i class="fas fa-circle" style="position: absolute;bottom: 0;right: 0;font-size: 1em;color: rgb(35,177,0);"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;font-size:10px;">
                            <div class="col m-auto p-0">
                                <div class="row m-0">
                                    <div class="col m-auto">
                                        <div style="width:50px; height:50px;position:relative;"><img src="assets/img/IMG_20151014_212349.jpg" width="50px;" style="border-radius:50%;" height="50px"><i class="fas fa-circle" style="position: absolute;bottom: 0;right: 0;font-size: 1em;color: rgb(35,177,0);"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m-0 justify-content-center">
                            <div class="col ml-auto"><a href="#" style="font-size: 0.8em;color: rgb(255,255,255);">View More...</a></div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;background-image: linear-gradient(#ff2727,#c50202);font-size: 0.5em;border:1px solid #c50202">
                            <div class="col m-0 p-0"><span class="m-2" style="font-size: 1.5em;"><i class="fas fa-globe-africa m-1" style="font-size: 1.4em;color: rgb(255,172,48);"></i><span class="m-1" style="color: rgb(255,255,255);"><strong>WEB</strong></span></span>
                            </div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;font-size:10px;">
                            <div class="col m-auto p-0">
                                <div class="row m-0">
                                    <div class="col m-auto">
                                        <div style="width:50px; height:50px;position:relative;"><img src="assets/img/IMG_20151014_212349.jpg" width="50px;" style="border-radius:50%;" height="50px"><i class="fas fa-circle" style="position: absolute;bottom: 0;right: 0;font-size: 1em;color: rgb(35,177,0);"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;font-size:10px;">
                            <div class="col m-auto p-0">
                                <div class="row m-0">
                                    <div class="col m-auto">
                                        <div style="width:50px; height:50px;position:relative;"><img src="assets/img/IMG_20151014_212349.jpg" width="50px;" style="border-radius:50%;" height="50px"><i class="fas fa-circle" style="position: absolute;bottom: 0;right: 0;font-size: 1em;color: rgb(35,177,0);"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m-0" style="padding: 5px 5px 5px 5px;font-size:10px;">
                            <div class="col m-auto p-0">
                                <div class="row m-0">
                                    <div class="col m-auto">
                                        <div style="width:50px; height:50px;position:relative;"><img src="assets/img/IMG_20151014_212349.jpg" width="50px;" style="border-radius:50%;" height="50px"><i class="fas fa-circle" style="position: absolute;bottom: 0;right: 0;font-size: 1em;color: rgb(35,177,0);"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row m-0 justify-content-center">
                            <div class="col ml-auto"><a href="#" style="font-size: 0.8em;color: rgb(255,255,255);">View More...</a></div>
                        </div>
                    </div>
                    <div class="body-member">
                        <div class="member-body-head">
                            <div class="row m-0">
                                <div class="col-auto col-sm-12 col-md-auto col-lg-auto col-xl-auto m-auto" style="color: rgb(255,255,255);">
                                    <h3>LucyFordModel69</h3>
                                </div>
                                <div class="col-sm-12 col-md-auto col-lg-auto col-xl-auto m-auto text-center" style="color: rgb(255,255,255);"><span>YouTube :</span><span><a href="#" style="color: rgb(255,208,42);">&nbsp;LucyFord Official</a></span></div>
                                <div class="col-auto col-sm-12 col-md-auto col-lg-auto col-xl-auto m-auto text-center" style="color: rgb(255,255,255);"><span>180kViews</span></div>
                                <div class="col-sm-12 col-md-auto col-lg-auto col-xl-auto m-auto text-center" style="color: rgb(255,255,255);">
                                    <p class="m-0" style="font-size: 0.8em;color: rgb(255,224,63);">Rate Me!!</p>
                                    <div class="rating" style="color: rgb(255,216,12);"><span><i class="fa fa-star"></i></span><span><i class="fa fa-star"></i></span><span><i class="fa fa-star"></i></span><span><i class="fa fa-star"></i></span><span><i class="fa fa-star"></i></span></div>
                                    <p class="m-0"
                                       style="font-size: 0.8em;">4.87 Stars</p>
                                </div>
                                <div class="col-2 col-sm-12 col-md-auto col-lg-auto col-xl-auto m-auto text-center" style="color: rgb(255,255,255);"><button class="btn btn-primary btn-follow" type="button" style="color: rgb(6,5,5);"><strong>Follow</strong><i class="fas fa-user m-1"></i></button></div>
                            </div>
                        </div>
                        <div class="d-flex">
                            <div class="profile">
                                <div class="row m-0 p-0">
                                    <div class="col m-0 p-0">
                                        <div><img src="assets/img/4.jpg" width="100%"></div>
                                        <div class="overley-prof-text mb-3">
                                            <div class="row m-0 p-2" style="font-size: 0.8em;">
                                                <div class="col-auto"><span id="staus" class="tabs" style="border-bottom: 2px solid red; padding-bottom: 9px;color:red;"><span style="font-size: 12px;color:white;"><strong>All Photos</strong></span></span>
                                                </div>
                                                <div class="col-auto"><span class="tabs" style="color:white;">Most Popular</span></div>
                                                <div class="col-auto"><span class="tabs" style="color:white;">Tracked</span></div>
                                                <div class="col-auto"><span class="tabs" style="color:white;">Albums</span></div>
                                            </div>
                                        </div>
                                        <div class="overflow-prof"></div>
                                    </div>
                                </div>
                                <div class="row m-0 p-2">
                                    <div class="col">
                                        <div class="row">
                                            <div class="col">
                                                <h5 style="font-style: italic;color: rgb(137,137,137);">About</h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col">
                                                <p style="word-wrap: break-word;color: rgb(171,171,171);">Zmjkaslk;ksdjsajdsldjklsdjlsdajdsdjlskjdakldlsjdsaljdlsjdaljdl<br>asdkjlkadlksajdsadjsjdadjksljdldjsljdaljdkjksjdkalsdjklsdjlsd<br>sdsadasdsdasdsddjsljkadklsdlskadskhdjskhadhsdjhdkahds<br>dsasdjaslkdjasdklsjdlkjdkljdklsjdklsdls</p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col">
                                                <h5 style="font-style: italic;color: rgb(136,136,136);">General Rules</h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col">
                                                <p style="word-wrap: break-word;color: rgb(171,171,171);">Zmjkaslk;ksdjsajdsldjklsdjlsdajdsdjlskjdakldlsjdsaljdlsjdaljdl<br>asdkjlkadlksajdsadjsjdadjksljdldjsljdaljdkjksjdkalsdjklsdjlsd<br>sdsadasdsdasdsddjsljkadklsdlskadskhdjskhadhsdjhdkahds<br>dsasdjaslkdjasdklsjdlkjdkljdklsjdklsdls</p>
                                            </div>
                                        </div>
                                        <div class="row"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="galary">
                                <div class="row m-0 p-2 mb-3" style="font-size: 0.8em;color: rgb(174,174,174);">
                                    <div class="col-auto"><span id="staus" class="tabs" style="border-bottom: 2px solid red; padding-bottom: 9px;color:red;"><span style="font-size: 12px;"><strong>All Photos</strong></span></span>
                                    </div>
                                    <div class="col-auto"><span class="tabs">Vidoes</span></div>
                                    <div class="col-auto"><span class="tabs">More</span></div>
                                    <div class="col-auto"><span class="tabs">Spotlight</span></div>
                                    <div class="col-auto"><span class="tabs">Followers</span></div>
                                </div>
                                <div class="row m-1">
                                    <div class="col"><input type="text" class="search" style="width: 100%;-moz-box-shadow: inset 0 0 10px #000000;-webkit-box-shadow: inset 0 0 10px #000000;box-shadow: inset 0 0 10px #000000;background-color: rgb(239,239,239);padding:5px;border-radius:7px;"
                                                            placeholder="Search by keyword, Tracks, Albums"></div>
                                </div>
                                <div class="row m-1 p-1">
                                    <div class="col m-auto">
                                        <div class="img- box"><img src="assets/img/4.jpg" width="100%" style="object-fit:cover;"></div>
                                        <div class="img- box"><img src="assets/img/IMG_20151014_212349.jpg" width="100%" style="object-fit:cover;"></div>
                                        <div class="img- box"><img src="assets/img/Ball2%20(1).png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20349.png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20213.png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20355%20(1).png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20348.png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/4.jpg" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20213.png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20355%20(1).png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20348.png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/4.jpg" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20213.png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20355%20(1).png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20348.png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/4.jpg" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20213.png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20355%20(1).png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/Layer%20348.png" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                        <div class="img- box"><img src="assets/img/4.jpg" width="100%" style="object-fit:cover;position:absolute;" height="100%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newapp\resources\views/themes/profile/index.blade.php ENDPATH**/ ?>
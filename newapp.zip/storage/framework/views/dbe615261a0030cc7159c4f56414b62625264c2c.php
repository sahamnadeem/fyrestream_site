<?php echo $__env->yieldPushContent('before-scripts'); ?>
<script src=" <?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src=" <?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src=" <?php echo e(asset('assets/js/index.js')); ?>"></script>
<?php echo $__env->yieldPushContent('after-scripts'); ?>
<?php /**PATH C:\Users\saham\Desktop\newapp\resources\views/themes/includes/footer-scripts.blade.php ENDPATH**/ ?>
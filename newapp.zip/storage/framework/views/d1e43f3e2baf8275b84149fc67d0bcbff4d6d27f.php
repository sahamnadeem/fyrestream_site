<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>fyreproto</title>
    <?php echo $__env->make('themes.includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<?php /**PATH C:\Users\ali jan\Desktop\fyerstream\resources\views/themes/includes/head.blade.php ENDPATH**/ ?>
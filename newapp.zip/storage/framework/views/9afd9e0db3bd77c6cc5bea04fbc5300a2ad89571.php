<?php $__env->startSection('main-content'); ?>
    <div class="container" style="margin-top: 7em;">
        <form action="<?php echo e(route('update-profile',['id'=>$user->id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="">Username</label>
                        <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="password" name="password" value="<?php echo e($user->name); ?>" disabled class="form-control">
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="">Address</label>
                        <input type="text" name="address" value="<?php echo e($user->profile->address); ?>" class="form-control">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="">Phone No.</label>
                        <input type="text" name="phone_no" class="form-control" value="<?php echo e($user->profile->phone_no); ?>">
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="">Hours of Availability</label>
                        <input type="text" name="hours_of_operation" value="<?php echo e($user->profile->hours_of_operation); ?>" class="form-control">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="">General Rules</label>
                        <textarea rows="3" name="general_roles" class="form-control"><?php echo e($user->profile->general_roles); ?></textarea>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="">About</label>
                        <textarea rows="3" name="about_us" class="form-control"><?php echo e($user->profile->about_us); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="">Deals</label>
                        <input type="text" name="deal" class="form-control" value="<?php echo e($user->profile->deal); ?>">
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="">Youtube</label>
                        <input type="text" name="youtube" class="form-control" value="<?php echo e($user->profile->youtube); ?>"/>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="">Instagram</label>
                        <input type="text" name="instagram" class="form-control" value="<?php echo e($user->profile->instagram); ?>"/>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <button class="btn btn-danger btn-block myupdatebtn" type="submit">Update</button>
                </div>
            </div>
        </form>
    </div>
    <br/>
    <br/>
    <br/>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('themes.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saham\Desktop\newapp\resources\views/themes/settings/index.blade.php ENDPATH**/ ?>
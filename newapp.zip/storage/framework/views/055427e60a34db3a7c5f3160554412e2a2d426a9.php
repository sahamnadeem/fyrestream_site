<?php echo $__env->yieldPushContent('before-style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto+Slab:300,400|Roboto:300,400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto+Slab:300,400|Roboto:300,400,700">
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/sticky-dark-top-nav-with-dropdown.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.css')); ?>">
<?php echo $__env->yieldPushContent('after-style'); ?>
<?php /**PATH C:\Users\ali jan\Desktop\fyerstream\resources\views/themes/includes/styles.blade.php ENDPATH**/ ?>
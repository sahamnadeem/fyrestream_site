<div class="row" style="margin-top:10px;">
    <div class="col">
        <div class="card-fyre" style="position:sticky;">
            <div class="card-fyre-header">
                <div class="row" style="margin:0px;padding:5px;">
                    <div class="col-1 m-auto" style="margin:0px;padding:0px;"><img src="assets/img/IMG_20151014_212349.jpg" width="40px" style="border-radius:50%;"></div>
                    <div class="col-10 m-auto p-1">
                        <h6 style="margin: 0px;font-size: 0.9em;"><strong>Nadeem Anjum</strong></h6>
                        <p style="font-size: 12px;color: rgb(152,152,152);padding:0px;margin:0px;"><strong>4 hrs ago</strong><i class="fas fa-globe-asia ml-2"></i></p>
                    </div>
                    <div class="col-auto m-auto" style="padding: 0px;color: rgb(188,188,188);"><span style="cursor:pointer;"><i class="fas fa-circle" style="font-size: 5px;margin:1px;float:right;"></i><i class="fas fa-circle" style="font-size: 5px;margin:1px;float:right;"></i><i class="fas fa-circle" style="font-size: 5px;margin:1px;float:right;"></i></span></div>
                </div>
            </div>
            <hr style="height: 1px;background: grey;background-color: rgb(234,234,234);margin:0px">
            <div class="container" style="padding:10px;">
                <div class="row mb-2" style="margin:0px;">
                    <div class="col"><img src="assets/img/Layer%20349.png" width="100%"></div>
                </div>
                <div class="row mt-1" style="margin:0px;">
                    <div class="col" style="color: rgb(162,162,162);">
                        <div style="display:inline-block;">
                            <div class="lss shaddow" style="display:inline-block;"><i class="far fa-thumbs-up" style="display: block;margin: auto;font-size: 1em;"></i></div><span style="font-size: 0.8em;color: rgb(188,188,188);margin-left:8px;">1</span></div>
                        <div style="display:inline-block;margin-left:10px;">
                            <div class="lss shaddow" style="display:inline-block;"><i class="far fa-comment-dots" style="display: block;margin: auto;font-size: 1em;"></i></div>
                        </div>
                        <div style="display:inline-block;margin-left:10px;">
                            <div class="lss shaddow" style="display:inline-block;"><i class="fas fa-share-alt m-auto d-block" style="font-size: 1em;"></i></div>
                        </div>
                    </div>
                </div>
            </div>
            <hr style="height: 1px;background: grey;background-color: rgb(234,234,234);margin:0px">
            <div style="padding:6px;">
                <div class="row p-2" style="margin:0;">
                    <div class="col-auto" style="padding:0px;"><img src="assets/img/Layer%20349.png" width="30px" style="border-radius:50%;"></div>
                    <div class="col m-auto">
                        <p style="font-size: 0.8em;padding:0px; margin:0px;"><strong>Saham Nadeem wazir khan </strong></p>
                        <p style="font-size: 0.8em;padding: 0px;margin: 0px;">comment lorem ipsum dummy data&nbsp;comment lorem ipsum dummy data&nbsp;comment lorem ipsum dummy data comment lorem ipsum dummy data<br></p>
                        <p style="font-size: 0.8em;padding: 0px;margin: 0px;color: rgb(163,163,163);"><i class="far fa-thumbs-up"></i><span class="ml-2" style="color: rgb(137,137,241);cursor:pointer;"><strong>Reply</strong></span><span class="ml-2">4hr ago</span></p>
                    </div>
                </div>
                <div class="row" style="margin:0;">
                    <div class="col-auto m-auto" style="padding:0px;"><img src="assets/img/IMG_20151014_212349.jpg" width="30px" style="border-radius:50%;"></div>
                    <div class="col m-auto" style="padding:5px;"><textarea class="status" placeholder="Write a comment..." style="color: rgb(136,136,136);background-color: rgba(255,255,255,0);padding: 5px;width:100%;" rows="1" spellcheck="true" wrap="soft"></textarea></div>
                    <div class="col-auto m-auto" style="color: rgb(190,190,190);font-size: 1em;padding: 0px;"><span class="m-1"><i class="fas fa-camera"></i></span><span class="m-1"><i class="fas fa-sticky-note"></i></span><span class="m-1"><i class="fas fa-smile"></i></span></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\newapp\resources\views/themes/includes/post.blade.php ENDPATH**/ ?>
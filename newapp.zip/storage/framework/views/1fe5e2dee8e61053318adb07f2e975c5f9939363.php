<script src=" <?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src=" <?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src=" <?php echo e(asset('assets/js/index.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\newapp\resources\views/themes/includes/footer-scripts.blade.php ENDPATH**/ ?>
<div class="topline"></div>
<div class="footer">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-auto" style="margin:3em;"><img src="assets/img/Layer247.png">
                <div class="row">
                    <div class="col text-center linksf">
                        <span>text</span> | <span>text</span> | <span>text</span> | <span>text</span> | <span>text</span> | <span>text</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('themes.includes.footer-scripts')

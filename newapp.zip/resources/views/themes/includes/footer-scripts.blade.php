@stack('before-scripts')
<script src=" {{asset('assets/js/jquery.min.js')}}"></script>
<script src=" {{asset('assets/bootstrap/js/bootstrap.min.js')}}"></script>
<script src=" {{asset('assets/js/index.js')}}"></script>
@stack('after-scripts')
